from .dimp import DiMP

def get_tracker_class():
    return DiMP